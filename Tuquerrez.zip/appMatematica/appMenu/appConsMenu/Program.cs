﻿using appMatematica.Presentacion.Consola;

namespace appConsMenu
{
    class Program
    {
        static void Main(string[] args)
        {
            new clsMnuPrincipal();
        }
    }
} 
